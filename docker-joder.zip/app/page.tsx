"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Terminal, Hash, Lock, ChevronRight, Upload, CheckCircle, XCircle } from "lucide-react"
import { calculateMD5, calculateHash } from "@/utils/hash"

interface ProgramData {
  name: string
  description: string
  md5: string
  sha1: string
  sha256: string
}

const programs: ProgramData[] = [
  {
    name: "plink.exe",
    description: "PuTTY Link - SSH Client",
    md5: "269ce7b3a3fcdf735cd8a37c04abfdae",
    sha1: "46ddfbbb5b4193279b9e024a5d013f5d825fcdf5",
    sha256: "50479953865b30775056441b10fdcb984126ba4f98af4f64756902a807b453e7",
  },
  {
    name: "putty.exe",
    description: "PuTTY - Terminal Emulator",
    md5: "36e31f610eef3223154e6e8fd074190f",
    sha1: "1f2800382cd71163c10e5ce0a32b60297489fbb5",
    sha256: "16cbe40fb24ce2d422afddb5a90a5801ced32ef52c22c2fc77b25a90837f28ad",
  },
  {
    name: "VirtualBox 7.0.8",
    description: "VirtualBox - VM Platform",
    md5: "5277068968032af616e7e4cc86f1d3c2",
    sha1: "6e3e2912d2131bb249f416088ee49088ab841580",
    sha256: "8a2da26ca69c1ddfc50fb65ee4fa8f269e692302046df4e2f48948775ba6339a",
  },
]

export default function HashIdentifierPage() {
  const [selectedProgram, setSelectedProgram] = useState<number | null>(null)
  const [displayedHashes, setDisplayedHashes] = useState<{
    md5: string
    sha1: string
    sha256: string
  } | null>(null)
  const [completedHashes, setCompletedHashes] = useState({
    md5: false,
    sha1: false,
    sha256: false,
  })
  const [isComparing, setIsComparing] = useState(false)
  const [comparisonResult, setComparisonResult] = useState<{
    status: "success" | "error" | null
    message: string
    fileName: string
  } | null>(null)

  const handleProgramClick = (index: number) => {
    setSelectedProgram(index)
    const program = programs[index]

    setCompletedHashes({ md5: false, sha1: false, sha256: false })
    setDisplayedHashes({ md5: "", sha1: "", sha256: "" })

    // MD5 animation
    setTimeout(() => {
      animateHash("md5", program.md5)
    }, 300)

    // SHA1 animation
    setTimeout(() => {
      animateHash("sha1", program.sha1)
    }, 800)

    // SHA256 animation
    setTimeout(() => {
      animateHash("sha256", program.sha256)
    }, 1300)
  }

  const animateHash = (type: "md5" | "sha1" | "sha256", fullHash: string) => {
    let currentHash = ""
    const interval = setInterval(() => {
      if (currentHash.length < fullHash.length) {
        currentHash += fullHash[currentHash.length]
        setDisplayedHashes((prev) => ({
          ...prev!,
          [type]: currentHash,
        }))
      } else {
        clearInterval(interval)
        setCompletedHashes((prev) => ({ ...prev, [type]: true }))
      }
    }, 20)
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    console.log("[v0] Archivo seleccionado:", file.name, "Tamaño:", file.size, "bytes", "Tipo:", file.type)

    const maxSize = 100 * 1024 * 1024 // 100MB
    if (file.size > maxSize) {
      setComparisonResult({
        status: "error",
        message: "El archivo es demasiado grande. Tamaño máximo: 100MB",
        fileName: file.name,
      })
      return
    }

    setIsComparing(true)
    setComparisonResult(null)

    try {
      console.log("[v0] Leyendo archivo...")
      const arrayBuffer = await file.arrayBuffer()
      console.log("[v0] Archivo leído. Tamaño del buffer:", arrayBuffer.byteLength)

      if (!arrayBuffer || arrayBuffer.byteLength === 0) {
        throw new Error("El archivo está vacío o no se pudo leer")
      }

      console.log("[v0] Calculando MD5...")
      const md5Hash = await calculateMD5(arrayBuffer)
      console.log("[v0] MD5 calculado:", md5Hash)

      console.log("[v0] Calculando SHA-1...")
      const sha1Hash = await calculateHash(arrayBuffer, "SHA-1")
      console.log("[v0] SHA-1 calculado:", sha1Hash)

      console.log("[v0] Calculando SHA-256...")
      const sha256Hash = await calculateHash(arrayBuffer, "SHA-256")
      console.log("[v0] SHA-256 calculado:", sha256Hash)

      console.log("[v0] Comparando con programas conocidos...")
      const matchedProgram = programs.find(
        (prog) =>
          prog.md5.toLowerCase() === md5Hash.toLowerCase() &&
          prog.sha1.toLowerCase() === sha1Hash.toLowerCase() &&
          prog.sha256.toLowerCase() === sha256Hash.toLowerCase(),
      )

      if (matchedProgram) {
        console.log("[v0] Programa coincidente encontrado:", matchedProgram.name)
        setComparisonResult({
          status: "success",
          message: `${matchedProgram.name} AUTÉNTICO - Todos los hashes coinciden`,
          fileName: file.name,
        })
      } else {
        console.log("[v0] No se encontró coincidencia")
        console.log("[v0] Hashes calculados - MD5:", md5Hash, "SHA-1:", sha1Hash, "SHA-256:", sha256Hash)
        setComparisonResult({
          status: "error",
          message: "ARCHIVO NO RECONOCIDO - Los hashes no coinciden con ningún programa conocido",
          fileName: file.name,
        })
      }
    } catch (error) {
      console.error("[v0] Error procesando archivo:", error)
      const errorMessage = error instanceof Error ? error.message : "Error desconocido"
      setComparisonResult({
        status: "error",
        message: `Error al procesar el archivo: ${errorMessage}`,
        fileName: file.name,
      })
    } finally {
      setIsComparing(false)
      event.target.value = ""
    }
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Scanline effect */}
      <div className="scanline" />

      {/* Grid background */}
      <div className="fixed inset-0 opacity-10 pointer-events-none">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(rgba(0, 255, 0, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 0, 0.1) 1px, transparent 1px)",
            backgroundSize: "50px 50px",
          }}
        />
      </div>

      <div className="relative z-10 container max-w-6xl mx-auto px-4 py-12">
        {/* Header */}
        <div className="text-center mb-12 space-y-4">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Terminal className="w-10 h-10 text-primary" />
            <h1 className="text-4xl md:text-6xl font-bold text-primary tracking-wider">ESTIFENSO</h1>
          </div>
          <div className="flex items-center justify-center gap-2">
            <Hash className="w-5 h-5 text-accent" />
            <p className="text-xl md:text-2xl text-accent tracking-wide">HASH IDENTIFY SYSTEM</p>
          </div>
          <p className="text-sm text-muted-foreground font-mono">
            {">"} Select a program to reveal cryptographic signatures
          </p>
        </div>

        {/* Compare button for file upload */}
        <Card className="p-6 mb-8 border-2 border-accent bg-card/80">
          <div className="flex flex-col items-center gap-4">
            <div className="flex items-center gap-3">
              <Upload className="w-6 h-6 text-accent" />
              <h3 className="text-xl font-bold text-primary font-mono">COMPARAR ARCHIVO</h3>
            </div>
            <p className="text-sm text-muted-foreground font-mono text-center">
              {">"} Sube un archivo para verificar si coincide con los programas conocidos
            </p>
            <label
              htmlFor="file-upload"
              className="cursor-pointer bg-primary hover:bg-primary/80 text-background px-6 py-3 rounded font-mono font-bold transition-all duration-300 hover:shadow-lg hover:shadow-primary/50 flex items-center gap-2"
            >
              <Upload className="w-5 h-5" />
              COMPARE
            </label>
            <input id="file-upload" type="file" onChange={handleFileUpload} className="hidden" disabled={isComparing} />

            {isComparing && (
              <div className="text-accent font-mono text-sm animate-pulse">{">"} Calculando hashes...</div>
            )}

            {comparisonResult && (
              <Card
                className={`p-4 w-full border-2 ${
                  comparisonResult.status === "success"
                    ? "border-primary bg-primary/10"
                    : "border-destructive bg-destructive/10"
                }`}
              >
                <div className="flex items-start gap-3">
                  {comparisonResult.status === "success" ? (
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                  ) : (
                    <XCircle className="w-6 h-6 text-destructive flex-shrink-0 mt-1" />
                  )}
                  <div className="flex-1">
                    <p className="font-mono font-bold text-sm mb-1">
                      {comparisonResult.status === "success" ? "[VERIFICACIÓN EXITOSA]" : "[VERIFICACIÓN FALLIDA]"}
                    </p>
                    <p className="text-sm font-mono mb-2">{comparisonResult.message}</p>
                    <p className="text-xs text-muted-foreground font-mono">Archivo: {comparisonResult.fileName}</p>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </Card>

        {/* Program Selection Grid */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          {programs.map((program, index) => (
            <Card
              key={index}
              className={`p-6 cursor-pointer transition-all duration-300 border-2 hover:border-primary hover:shadow-lg hover:shadow-primary/20 ${
                selectedProgram === index ? "border-primary bg-primary/10" : "border-border bg-card"
              }`}
              onClick={() => handleProgramClick(index)}
            >
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-bold text-lg text-primary mb-1 font-mono">{program.name}</h3>
                  <p className="text-sm text-muted-foreground">{program.description}</p>
                  <div className="mt-3 flex items-center gap-2 text-xs text-accent">
                    <ChevronRight className="w-4 h-4" />
                    <span>Click to analyze</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Hash Display */}
        {selectedProgram !== null && displayedHashes && (
          <Card className="p-8 border-2 border-primary bg-card/80 backdrop-blur">
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-border">
                <Terminal className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-primary font-mono">{programs[selectedProgram].name}</h2>
              </div>

              {/* MD5 */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-accent font-bold font-mono">[MD5]</span>
                  <span className="text-xs text-muted-foreground">(128-bit hash)</span>
                </div>
                <div className="bg-secondary/50 p-4 rounded border border-border">
                  <code className="text-primary font-mono text-sm break-all">
                    {displayedHashes.md5 || "_"}
                    {!completedHashes.md5 && <span className="animate-pulse ml-0.5">|</span>}
                  </code>
                </div>
              </div>

              {/* SHA1 */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-accent font-bold font-mono">[SHA-1]</span>
                  <span className="text-xs text-muted-foreground">(160-bit hash)</span>
                </div>
                <div className="bg-secondary/50 p-4 rounded border border-border">
                  <code className="text-primary font-mono text-sm break-all">
                    {displayedHashes.sha1 || "_"}
                    {!completedHashes.sha1 && <span className="animate-pulse ml-0.5">|</span>}
                  </code>
                </div>
              </div>

              {/* SHA256 */}
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-accent font-bold font-mono">[SHA-256]</span>
                  <span className="text-xs text-muted-foreground">(256-bit hash)</span>
                </div>
                <div className="bg-secondary/50 p-4 rounded border border-border">
                  <code className="text-primary font-mono text-sm break-all">
                    {displayedHashes.sha256 || "_"}
                    {!completedHashes.sha256 && <span className="animate-pulse ml-0.5">|</span>}
                  </code>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-border">
                <p className="text-xs text-muted-foreground font-mono text-center">
                  {">"} Hash verification completed successfully
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Instructions when no program selected */}
        {selectedProgram === null && (
          <Card className="p-8 border-2 border-dashed border-border bg-card/50">
            <div className="text-center space-y-4">
              <Hash className="w-12 h-12 text-muted-foreground mx-auto" />
              <p className="text-muted-foreground font-mono">{">"} No program selected</p>
              <p className="text-sm text-muted-foreground">
                Click on any program above to display its cryptographic hashes
              </p>
            </div>
          </Card>
        )}

        {/* Footer */}
        <div className="mt-12 text-center">
          <p className="text-xs text-muted-foreground font-mono">
            {">"} Todos Los Derechos Reservados | Estifenso Hash Indetify |{" "}
            <a
              href="https://estifenso.me/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:text-accent transition-colors underline"
            >
              estifenso.me
            </a>
          </p>
        </div>
      </div>
    </div>
  )
}
