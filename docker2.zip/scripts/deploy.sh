#!/bin/bash

# Script de despliegue rápido

echo "🚀 Desplegando aplicación..."

# Colores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m'

info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
    exit 1
}

# Verificar que Docker está corriendo
if ! docker info > /dev/null 2>&1; then
    error "Docker no está corriendo. Ejecuta: sudo systemctl start docker"
fi

# Detener contenedores existentes
info "Deteniendo contenedores existentes..."
docker-compose down

# Construir imágenes
info "Construyendo imágenes..."
docker-compose build || error "Error al construir imágenes"

# Levantar servicios
info "Levantando servicios..."
docker-compose up -d || error "Error al levantar servicios"

# Esperar a que los servicios estén listos
info "Esperando a que los servicios estén listos..."
sleep 5

# Verificar estado
info "Verificando estado de contenedores..."
docker-compose ps

# Mostrar logs
echo ""
info "Últimos logs:"
docker-compose logs --tail=20

echo ""
success "¡Despliegue completado!"
echo ""
info "Accede a tu aplicación en:"
echo "  HTTP:  http://localhost"
echo "  HTTPS: https://localhost"
echo ""
info "Ver logs en tiempo real:"
echo "  docker-compose logs -f"
