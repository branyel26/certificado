# Guía de Despliegue Docker

Esta guía te ayudará a desplegar tu aplicación Next.js en un servidor Ubuntu usando Docker y Nginx con soporte SSL.

## Requisitos Previos

- Servidor Ubuntu (20.04 o superior)
- Dominio apuntando a la IP de tu servidor
- Docker y Docker Compose instalados

## Instalación de Docker en Ubuntu

\`\`\`bash
# Actualizar paquetes
sudo apt update && sudo apt upgrade -y

# Instalar dependencias
sudo apt install -y apt-transport-https ca-certificates curl software-properties-common

# Agregar clave GPG de Docker
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

# Agregar repositorio de Docker
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Instalar Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io

# Instalar Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Agregar usuario al grupo docker
sudo usermod -aG docker $USER
newgrp docker
\`\`\`

## Configuración Inicial

### 1. Subir el proyecto al servidor

\`\`\`bash
# Desde tu máquina local
scp -r /ruta/a/tu/proyecto usuario@ip-servidor:/home/usuario/app
\`\`\`

O usa Git:

\`\`\`bash
# En el servidor
cd /home/usuario
git clone https://github.com/tu-usuario/tu-repositorio.git app
cd app
\`\`\`

### 2. Crear directorios necesarios

\`\`\`bash
mkdir -p nginx/logs nginx/ssl nginx/conf.d
\`\`\`

### 3. Generar certificados SSL autofirmados (para pruebas)

\`\`\`bash
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout nginx/ssl/self-signed.key \
  -out nginx/ssl/self-signed.crt \
  -subj "/C=ES/ST=State/L=City/O=Organization/CN=localhost"
\`\`\`

## Obtener Certificados SSL con Let's Encrypt (Producción)

### Opción 1: Con Certbot standalone

\`\`\`bash
# Instalar Certbot
sudo apt install -y certbot

# Detener servicios en puertos 80/443 si existen
sudo systemctl stop nginx

# Obtener certificado
sudo certbot certonly --standalone -d tudominio.com -d www.tudominio.com

# Copiar certificados a la carpeta del proyecto
sudo cp /etc/letsencrypt/live/tudominio.com/fullchain.pem nginx/ssl/
sudo cp /etc/letsencrypt/live/tudominio.com/privkey.pem nginx/ssl/
sudo chown $USER:$USER nginx/ssl/*.pem
\`\`\`

### Opción 2: Con Docker Certbot (Recomendado)

Modificar `docker-compose.yml` para incluir Certbot:

\`\`\`yaml
services:
  certbot:
    image: certbot/certbot
    container_name: estifenso-certbot
    volumes:
      - ./nginx/ssl:/etc/letsencrypt
      - ./nginx/www:/var/www/certbot
    entrypoint: "/bin/sh -c 'trap exit TERM; while :; do certbot renew; sleep 12h & wait $${!}; done;'"
\`\`\`

Ejecutar certificación inicial:

\`\`\`bash
docker-compose run --rm certbot certonly --webroot \
  -w /var/www/certbot \
  -d tudominio.com -d www.tudominio.com \
  --email tu@email.com \
  --agree-tos \
  --no-eff-email
\`\`\`

### 4. Actualizar configuración de Nginx

Editar `nginx/conf.d/default.conf` y descomentar las líneas de certificados SSL reales:

\`\`\`nginx
# ssl_certificate /etc/nginx/ssl/fullchain.pem;
# ssl_certificate_key /etc/nginx/ssl/privkey.pem;
\`\`\`

Y comentar los certificados autofirmados.

## Construcción y Despliegue

### 1. Construir y levantar contenedores

\`\`\`bash
# Construir imágenes
docker-compose build

# Levantar servicios en segundo plano
docker-compose up -d
\`\`\`

### 2. Verificar estado

\`\`\`bash
# Ver logs
docker-compose logs -f

# Ver contenedores corriendo
docker ps

# Ver logs de nginx
docker-compose logs nginx

# Ver logs de la app
docker-compose logs nextjs-app
\`\`\`

### 3. Probar la aplicación

\`\`\`bash
# HTTP (debería redirigir a HTTPS)
curl -I http://tudominio.com

# HTTPS
curl -I https://tudominio.com
\`\`\`

## Comandos Útiles

\`\`\`bash
# Detener servicios
docker-compose down

# Reconstruir y reiniciar
docker-compose up -d --build

# Ver logs en tiempo real
docker-compose logs -f nextjs-app

# Reiniciar solo nginx
docker-compose restart nginx

# Limpiar contenedores antiguos
docker system prune -a

# Acceder al contenedor
docker exec -it estifenso-hash-app sh
\`\`\`

## Actualización de la Aplicación

\`\`\`bash
# Detener servicios
docker-compose down

# Actualizar código (si usas Git)
git pull

# Reconstruir y reiniciar
docker-compose up -d --build
\`\`\`

## Firewall (UFW)

\`\`\`bash
# Permitir tráfico HTTP y HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Permitir SSH
sudo ufw allow 22/tcp

# Activar firewall
sudo ufw enable

# Ver estado
sudo ufw status
\`\`\`

## Renovación Automática de Certificados SSL

Si usaste Certbot con Docker, los certificados se renovarán automáticamente.

Para verificar:

\`\`\`bash
# Ver logs de certbot
docker-compose logs certbot
\`\`\`

## Troubleshooting

### Error: Puerto 80 o 443 ya en uso

\`\`\`bash
# Ver qué proceso usa el puerto
sudo lsof -i :80
sudo lsof -i :443

# Detener nginx del sistema si existe
sudo systemctl stop nginx
sudo systemctl disable nginx
\`\`\`

### Error: Permisos de certificados SSL

\`\`\`bash
sudo chown -R $USER:$USER nginx/ssl
chmod 644 nginx/ssl/*.pem
chmod 600 nginx/ssl/privkey.pem
\`\`\`

### Ver logs detallados de nginx

\`\`\`bash
docker exec estifenso-nginx cat /var/log/nginx/error.log
docker exec estifenso-nginx cat /var/log/nginx/access.log
\`\`\`

## Monitoreo

\`\`\`bash
# Ver uso de recursos
docker stats

# Ver logs específicos
docker-compose logs --tail=100 nextjs-app
\`\`\`

## Seguridad Adicional

1. Mantén Docker actualizado
2. Usa variables de entorno para secretos (no las subas a Git)
3. Configura fail2ban para proteger contra ataques
4. Mantén los certificados SSL actualizados
5. Revisa logs regularmente

## Backup

\`\`\`bash
# Crear backup del código y configuración
tar -czf backup-$(date +%Y%m%d).tar.gz \
  --exclude=node_modules \
  --exclude=.next \
  --exclude=nginx/logs \
  .
\`\`\`

## Soporte

Para más información sobre Next.js y Docker, consulta:
- [Next.js Deployment](https://nextjs.org/docs/deployment)
- [Docker Documentation](https://docs.docker.com/)
- [Let's Encrypt Documentation](https://letsencrypt.org/docs/)
