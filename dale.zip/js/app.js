// Programs database
const programs = [
  {
    name: "plink.exe",
    description: "PuTTY Link - SSH Client",
    md5: "269ce7b3a3fcdf735cd8a37c04abfdae",
    sha1: "46ddfbbb5b4193279b9e024a5d013f5d825fcdf5",
    sha256: "50479953865b30775056441b10fdcb984126ba4f98af4f64756902a807b453e7",
  },
  {
    name: "putty.exe",
    description: "PuTTY - Terminal Emulator",
    md5: "36e31f610eef3223154e6e8fd074190f",
    sha1: "1f2800382cd71163c10e5ce0a32b60297489fbb5",
    sha256: "16cbe40fb24ce2d422afddb5a90a5801ced32ef52c22c2fc77b25a90837f28ad",
  },
  {
    name: "VirtualBox 7.0.8",
    description: "VirtualBox - VM Platform",
    md5: "5277068968032af616e7e4cc86f1d3c2",
    sha1: "6e3e2912d2131bb249f416088ee49088ab841580",
    sha256: "8a2da26ca69c1ddfc50fb65ee4fa8f269e692302046df4e2f48948775ba6339a",
  },
]

let selectedProgramIndex = null
const CHUNK_SIZE = 2 * 1024 * 1024 // 2MB chunks

// Initialize Lucide icons
document.addEventListener("DOMContentLoaded", () => {
  window.lucide.createIcons()

  // Setup event listeners
  setupProgramCards()
  setupFileUpload()
})

function setupProgramCards() {
  const programCards = document.querySelectorAll(".program-card")
  programCards.forEach((card, index) => {
    card.addEventListener("click", () => handleProgramClick(index))
  })
}

function handleProgramClick(index) {
  selectedProgramIndex = index
  const program = programs[index]

  // Update selected state
  document.querySelectorAll(".program-card").forEach((card, i) => {
    card.classList.toggle("selected", i === index)
  })

  // Show hash display and hide no-selection
  document.getElementById("hash-display").style.display = "block"
  document.getElementById("no-selection").style.display = "none"

  // Update program name
  document.getElementById("selected-program-name").textContent = program.name

  // Reset and animate hashes
  animateHash("md5", program.md5, 300)
  animateHash("sha1", program.sha1, 800)
  animateHash("sha256", program.sha256, 1300)
}

function animateHash(type, fullHash, delay) {
  const element = document.getElementById(`${type}-hash`)

  setTimeout(() => {
    let currentHash = ""
    let index = 0

    // Reset display
    element.innerHTML = '_<span class="cursor">|</span>'

    const interval = setInterval(() => {
      if (index < fullHash.length) {
        currentHash += fullHash[index]
        element.innerHTML = currentHash + '<span class="cursor">|</span>'
        index++
      } else {
        element.innerHTML = currentHash
        clearInterval(interval)
      }
    }, 20)
  }, delay)
}

function setupFileUpload() {
  const fileInput = document.getElementById("file-upload")
  fileInput.addEventListener("change", handleFileUpload)
}

async function handleFileUpload(event) {
  const file = event.target.files?.[0]
  if (!file) return

  console.log("[Hash] Archivo seleccionado:", file.name, "Tamaño:", file.size, "bytes")

  const maxSize = 100 * 1024 * 1024 // 100MB
  if (file.size > maxSize) {
    showComparisonResult("error", "El archivo es demasiado grande. Tamaño máximo: 100MB", file.name)
    return
  }

  // Show loading state
  document.getElementById("comparing-status").style.display = "block"
  document.getElementById("comparison-result").style.display = "none"

  try {
    console.log("[Hash] Leyendo archivo...")
    const arrayBuffer = await file.arrayBuffer()
    console.log("[Hash] Archivo leído. Tamaño del buffer:", arrayBuffer.byteLength)

    if (!arrayBuffer || arrayBuffer.byteLength === 0) {
      throw new Error("El archivo está vacío o no se pudo leer")
    }

    console.log("[Hash] Calculando MD5...")
    const md5Hash = await calculateMD5(arrayBuffer)
    console.log("[Hash] MD5 calculado:", md5Hash)

    console.log("[Hash] Calculando SHA-1...")
    const sha1Hash = await calculateHash(arrayBuffer, "SHA-1")
    console.log("[Hash] SHA-1 calculado:", sha1Hash)

    console.log("[Hash] Calculando SHA-256...")
    const sha256Hash = await calculateHash(arrayBuffer, "SHA-256")
    console.log("[Hash] SHA-256 calculado:", sha256Hash)

    console.log("[Hash] Comparando con programas conocidos...")
    const matchedProgram = programs.find(
      (prog) =>
        prog.md5.toLowerCase() === md5Hash.toLowerCase() &&
        prog.sha1.toLowerCase() === sha1Hash.toLowerCase() &&
        prog.sha256.toLowerCase() === sha256Hash.toLowerCase(),
    )

    if (matchedProgram) {
      console.log("[Hash] Programa coincidente encontrado:", matchedProgram.name)
      showComparisonResult("success", `${matchedProgram.name} AUTÉNTICO - Todos los hashes coinciden`, file.name)
    } else {
      console.log("[Hash] No se encontró coincidencia")
      console.log("[Hash] Hashes calculados - MD5:", md5Hash, "SHA-1:", sha1Hash, "SHA-256:", sha256Hash)
      showComparisonResult(
        "error",
        "ARCHIVO NO RECONOCIDO - Los hashes no coinciden con ningún programa conocido",
        file.name,
      )
    }
  } catch (error) {
    console.error("[Hash] Error procesando archivo:", error)
    const errorMessage = error instanceof Error ? error.message : "Error desconocido"
    showComparisonResult("error", `Error al procesar el archivo: ${errorMessage}`, file.name)
  } finally {
    document.getElementById("comparing-status").style.display = "none"
    event.target.value = ""
  }
}

function showComparisonResult(status, message, fileName) {
  const resultDiv = document.getElementById("comparison-result")
  const iconName = status === "success" ? "check-circle" : "x-circle"
  const statusText = status === "success" ? "[VERIFICACIÓN EXITOSA]" : "[VERIFICACIÓN FALLIDA]"

  resultDiv.innerHTML = `
        <div class="result-card ${status}">
            <i data-lucide="${iconName}" class="icon-medium"></i>
            <div class="result-content">
                <p class="result-status">${statusText}</p>
                <p class="result-message">${message}</p>
                <p class="result-file">Archivo: ${fileName}</p>
            </div>
        </div>
    `
  resultDiv.style.display = "block"
  window.lucide.createIcons()
}

// Hash calculation functions using CryptoJS
async function calculateMD5(arrayBuffer) {
  try {
    console.log("[Hash] Iniciando cálculo MD5, tamaño:", arrayBuffer.byteLength, "bytes")

    if (arrayBuffer.byteLength > 10 * 1024 * 1024) {
      return calculateMD5InChunks(arrayBuffer)
    }

    const uint8Array = new Uint8Array(arrayBuffer)
    const wordArray = window.CryptoJS.lib.WordArray.create(uint8Array)
    const hash = window.CryptoJS.MD5(wordArray)
    const result = hash.toString(window.CryptoJS.enc.Hex)
    console.log("[Hash] MD5 calculado exitosamente")
    return result
  } catch (error) {
    console.error("[Hash] Error calculando MD5:", error)
    throw new Error("Error al calcular MD5: " + (error.message || "Error desconocido"))
  }
}

function calculateMD5InChunks(arrayBuffer) {
  console.log("[Hash] Calculando MD5 por chunks...")
  const md5 = window.CryptoJS.algo.MD5.create()
  const uint8Array = new Uint8Array(arrayBuffer)

  for (let offset = 0; offset < uint8Array.length; offset += CHUNK_SIZE) {
    const end = Math.min(offset + CHUNK_SIZE, uint8Array.length)
    const chunk = uint8Array.slice(offset, end)
    const wordArray = window.CryptoJS.lib.WordArray.create(chunk)
    md5.update(wordArray)

    if (offset > 0 && offset % (10 * 1024 * 1024) === 0) {
      const progress = ((offset / uint8Array.length) * 100).toFixed(1)
      console.log(`[Hash] MD5 progreso: ${progress}%`)
    }
  }

  const hash = md5.finalize()
  console.log("[Hash] MD5 por chunks completado")
  return hash.toString(window.CryptoJS.enc.Hex)
}

async function calculateHash(buffer, algorithm) {
  try {
    console.log(`[Hash] Iniciando cálculo ${algorithm}, tamaño:`, buffer.byteLength, "bytes")

    if (buffer.byteLength > 10 * 1024 * 1024) {
      return calculateHashInChunks(buffer, algorithm)
    }

    const uint8Array = new Uint8Array(buffer)
    const wordArray = window.CryptoJS.lib.WordArray.create(uint8Array)

    let hash
    switch (algorithm.toUpperCase()) {
      case "SHA-1":
        hash = window.CryptoJS.SHA1(wordArray)
        break
      case "SHA-256":
        hash = window.CryptoJS.SHA256(wordArray)
        break
      case "SHA-512":
        hash = window.CryptoJS.SHA512(wordArray)
        break
      default:
        throw new Error(`Algoritmo no soportado: ${algorithm}`)
    }

    const result = hash.toString(window.CryptoJS.enc.Hex)
    console.log(`[Hash] ${algorithm} calculado exitosamente`)
    return result
  } catch (error) {
    console.error(`[Hash] Error calculando ${algorithm}:`, error)
    throw new Error(`Error al calcular ${algorithm}: ` + (error.message || "Error desconocido"))
  }
}

function calculateHashInChunks(buffer, algorithm) {
  console.log(`[Hash] Calculando ${algorithm} por chunks...`)

  try {
    let hasher
    switch (algorithm.toUpperCase()) {
      case "SHA-1":
        hasher = window.CryptoJS.algo.SHA1.create()
        break
      case "SHA-256":
        hasher = window.CryptoJS.algo.SHA256.create()
        break
      case "SHA-512":
        hasher = window.CryptoJS.algo.SHA512.create()
        break
      default:
        throw new Error(`Algoritmo no soportado: ${algorithm}`)
    }

    const uint8Array = new Uint8Array(buffer)

    for (let offset = 0; offset < uint8Array.length; offset += CHUNK_SIZE) {
      const end = Math.min(offset + CHUNK_SIZE, uint8Array.length)
      const chunk = uint8Array.slice(offset, end)
      const wordArray = window.CryptoJS.lib.WordArray.create(chunk)
      hasher.update(wordArray)

      if (offset > 0 && offset % (10 * 1024 * 1024) === 0) {
        const progress = ((offset / uint8Array.length) * 100).toFixed(1)
        console.log(`[Hash] ${algorithm} progreso: ${progress}%`)
      }
    }

    const hash = hasher.finalize()
    const result = hash.toString(window.CryptoJS.enc.Hex)
    console.log(`[Hash] ${algorithm} por chunks completado`)
    return result
  } catch (error) {
    console.error(`[Hash] Error en ${algorithm} por chunks:`, error)
    throw error
  }
}
