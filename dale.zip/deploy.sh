#!/bin/bash

# Script de despliegue para servidor Ubuntu con Nginx
# Este script instala todas las dependencias necesarias y despliega la aplicación

set -e

echo "========================================"
echo "Desplegando aplicación Next.js en Nginx"
echo "========================================"

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Variables
APP_NAME="miweb"
APP_DIR="/var/www/$APP_NAME"
USER=$(whoami)

# Función para imprimir mensajes
print_msg() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Verificar si se ejecuta con sudo para ciertas operaciones
if [ "$EUID" -ne 0 ]; then 
    print_warning "Este script necesita permisos sudo para algunas operaciones"
    print_msg "Se te pedirá la contraseña cuando sea necesario"
fi

# 1. Instalar Node.js si no está instalado
print_msg "Verificando Node.js..."
if ! command -v node &> /dev/null; then
    print_msg "Instalando Node.js..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
else
    print_msg "Node.js ya está instalado: $(node -v)"
fi

# 2. Instalar Nginx si no está instalado
print_msg "Verificando Nginx..."
if ! command -v nginx &> /dev/null; then
    print_msg "Instalando Nginx..."
    sudo apt-get update
    sudo apt-get install -y nginx
    sudo systemctl enable nginx
else
    print_msg "Nginx ya está instalado"
fi

# 3. Instalar PM2 globalmente si no está instalado
print_msg "Verificando PM2..."
if ! command -v pm2 &> /dev/null; then
    print_msg "Instalando PM2..."
    sudo npm install -g pm2
    pm2 startup systemd -u $USER --hp /home/$USER
else
    print_msg "PM2 ya está instalado"
fi

# 4. Crear directorio de la aplicación
print_msg "Creando directorio de la aplicación..."
sudo mkdir -p $APP_DIR
sudo chown -R $USER:$USER $APP_DIR

# 5. Copiar archivos de la aplicación
print_msg "Copiando archivos de la aplicación..."
rsync -av --exclude='node_modules' --exclude='.next' --exclude='.git' ./ $APP_DIR/

# 6. Instalar dependencias
print_msg "Instalando dependencias..."
cd $APP_DIR
npm install --legacy-peer-deps

# 7. Build de producción
print_msg "Generando build de producción..."
npm run build

# 8. Configurar Nginx
print_msg "Configurando Nginx..."
sudo cp nginx-production.conf /etc/nginx/sites-available/$APP_NAME

# Crear enlace simbólico si no existe
if [ ! -L /etc/nginx/sites-enabled/$APP_NAME ]; then
    sudo ln -s /etc/nginx/sites-available/$APP_NAME /etc/nginx/sites-enabled/$APP_NAME
fi

# Eliminar configuración por defecto si existe
if [ -L /etc/nginx/sites-enabled/default ]; then
    sudo rm /etc/nginx/sites-enabled/default
fi

# Verificar configuración de Nginx
print_msg "Verificando configuración de Nginx..."
sudo nginx -t

# Reiniciar Nginx
print_msg "Reiniciando Nginx..."
sudo systemctl restart nginx

# 9. Iniciar aplicación con PM2
print_msg "Iniciando aplicación con PM2..."
pm2 delete $APP_NAME 2>/dev/null || true
pm2 start npm --name "$APP_NAME" -- start
pm2 save

# 10. Verificar estado
print_msg "Verificando estado de los servicios..."
echo ""
echo "Estado de Nginx:"
sudo systemctl status nginx --no-pager | head -n 5
echo ""
echo "Estado de PM2:"
pm2 status

# 11. Información final
echo ""
echo "========================================"
echo -e "${GREEN}¡Despliegue completado exitosamente!${NC}"
echo "========================================"
echo ""
echo "Tu aplicación está corriendo en:"
echo "  - http://$(hostname -I | awk '{print $1}')"
echo "  - http://localhost"
echo ""
echo "Comandos útiles:"
echo "  Ver logs:        pm2 logs $APP_NAME"
echo "  Reiniciar app:   pm2 restart $APP_NAME"
echo "  Detener app:     pm2 stop $APP_NAME"
echo "  Estado PM2:      pm2 status"
echo "  Logs Nginx:      sudo tail -f /var/log/nginx/miweb-error.log"
echo ""
