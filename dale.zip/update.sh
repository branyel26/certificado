#!/bin/bash

# Script para actualizar la aplicación después del despliegue inicial

set -e

APP_NAME="miweb"
APP_DIR="/var/www/$APP_NAME"
USER=$(whoami)

GREEN='\033[0;32m'
NC='\033[0m'

print_msg() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_msg "Actualizando aplicación..."

# 1. Copiar archivos actualizados
print_msg "Copiando archivos..."
rsync -av --exclude='node_modules' --exclude='.next' --exclude='.git' ./ $APP_DIR/

# 2. Instalar nuevas dependencias si hay cambios
cd $APP_DIR
print_msg "Verificando dependencias..."
npm install --legacy-peer-deps

# 3. Rebuild
print_msg "Generando nuevo build..."
npm run build

# 4. Reiniciar aplicación
print_msg "Reiniciando aplicación..."
pm2 restart $APP_NAME

# 5. Verificar estado
print_msg "Estado de la aplicación:"
pm2 status $APP_NAME

echo ""
echo -e "${GREEN}¡Actualización completada!${NC}"
echo "La aplicación se ha reiniciado correctamente."
