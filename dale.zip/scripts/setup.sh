#!/bin/bash

# Script de configuración inicial para el servidor

echo "🚀 Iniciando configuración del servidor..."

# Colores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Función para mostrar mensajes
info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
}

# Verificar si es root
if [ "$EUID" -ne 0 ]; then 
    error "Este script debe ejecutarse como root (usa sudo)"
    exit 1
fi

# Actualizar sistema
info "Actualizando sistema..."
apt update && apt upgrade -y
success "Sistema actualizado"

# Instalar dependencias
info "Instalando dependencias..."
apt install -y apt-transport-https ca-certificates curl software-properties-common ufw
success "Dependencias instaladas"

# Instalar Docker
info "Instalando Docker..."
if ! command -v docker &> /dev/null; then
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt update
    apt install -y docker-ce docker-ce-cli containerd.io
    success "Docker instalado"
else
    success "Docker ya está instalado"
fi

# Instalar Docker Compose
info "Instalando Docker Compose..."
if ! command -v docker-compose &> /dev/null; then
    curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
    success "Docker Compose instalado"
else
    success "Docker Compose ya está instalado"
fi

# Configurar firewall
info "Configurando firewall..."
ufw --force enable
ufw allow 22/tcp   # SSH
ufw allow 80/tcp   # HTTP
ufw allow 443/tcp  # HTTPS
success "Firewall configurado"

# Crear directorios necesarios
info "Creando directorios..."
mkdir -p nginx/logs nginx/ssl nginx/conf.d nginx/www
success "Directorios creados"

# Generar certificados SSL autofirmados para pruebas
info "Generando certificados SSL de prueba..."
if [ ! -f nginx/ssl/self-signed.crt ]; then
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout nginx/ssl/self-signed.key \
        -out nginx/ssl/self-signed.crt \
        -subj "/C=ES/ST=State/L=City/O=Estifenso/CN=localhost"
    success "Certificados SSL generados"
else
    success "Certificados SSL ya existen"
fi

# Mostrar versiones instaladas
echo ""
info "Versiones instaladas:"
echo "  Docker: $(docker --version)"
echo "  Docker Compose: $(docker-compose --version)"

echo ""
success "¡Configuración completada!"
echo ""
info "Próximos pasos:"
echo "  1. Edita nginx/conf.d/default.conf con tu dominio"
echo "  2. Ejecuta: docker-compose build"
echo "  3. Ejecuta: docker-compose up -d"
echo "  4. Para SSL con Let's Encrypt, lee DEPLOYMENT.md"
