# Instalación

Simplemente copia todos los archivos a `/var/www/html` en tu servidor:

\`\`\`bash
sudo cp -r * /var/www/html/
\`\`\`

Asegúrate que Nginx tenga los permisos correctos:

\`\`\`bash
sudo chown -R www-data:www-data /var/www/html
sudo chmod -R 755 /var/www/html
\`\`\`

Luego accede a tu servidor en el navegador: `http://tu-servidor.com`

¡Listo! La aplicación funcionará inmediatamente.
