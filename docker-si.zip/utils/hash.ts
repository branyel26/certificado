import CryptoJS from "crypto-js"

const CHUNK_SIZE = 2 * 1024 * 1024 // 2MB chunks

export async function calculateMD5(arrayBuffer: ArrayBuffer): Promise<string> {
  try {
    console.log("[v0] Iniciando cálculo MD5, tamaño:", arrayBuffer.byteLength, "bytes")

    if (arrayBuffer.byteLength > 10 * 1024 * 1024) {
      // > 10MB
      return calculateMD5InChunks(arrayBuffer)
    }

    const uint8Array = new Uint8Array(arrayBuffer)
    const wordArray = CryptoJS.lib.WordArray.create(uint8Array as any)
    const hash = CryptoJS.MD5(wordArray)
    const result = hash.toString(CryptoJS.enc.Hex)
    console.log("[v0] MD5 calculado exitosamente")
    return result
  } catch (error) {
    console.error("[v0] Error calculando MD5:", error)
    throw new Error("Error al calcular MD5: " + (error instanceof Error ? error.message : "Error desconocido"))
  }
}

function calculateMD5InChunks(arrayBuffer: ArrayBuffer): string {
  console.log("[v0] Calculando MD5 por chunks...")
  const md5 = CryptoJS.algo.MD5.create()
  const uint8Array = new Uint8Array(arrayBuffer)

  for (let offset = 0; offset < uint8Array.length; offset += CHUNK_SIZE) {
    const end = Math.min(offset + CHUNK_SIZE, uint8Array.length)
    const chunk = uint8Array.slice(offset, end)
    const wordArray = CryptoJS.lib.WordArray.create(chunk as any)
    md5.update(wordArray)

    // Log progreso cada 10MB
    if (offset > 0 && offset % (10 * 1024 * 1024) === 0) {
      const progress = ((offset / uint8Array.length) * 100).toFixed(1)
      console.log(`[v0] MD5 progreso: ${progress}%`)
    }
  }

  const hash = md5.finalize()
  console.log("[v0] MD5 por chunks completado")
  return hash.toString(CryptoJS.enc.Hex)
}

export async function calculateHash(buffer: ArrayBuffer, algorithm: string): Promise<string> {
  try {
    console.log(`[v0] Iniciando cálculo ${algorithm}, tamaño:`, buffer.byteLength, "bytes")

    if (buffer.byteLength > 10 * 1024 * 1024) {
      // > 10MB
      return calculateHashInChunks(buffer, algorithm)
    }

    const hashBuffer = await crypto.subtle.digest(algorithm, buffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const result = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
    console.log(`[v0] ${algorithm} calculado exitosamente`)
    return result
  } catch (error) {
    console.error(`[v0] Error calculando ${algorithm}:`, error)
    throw new Error(`Error al calcular ${algorithm}: ` + (error instanceof Error ? error.message : "Error desconocido"))
  }
}

async function calculateHashInChunks(buffer: ArrayBuffer, algorithm: string): Promise<string> {
  console.log(`[v0] Calculando ${algorithm} por chunks...`)

  // Para Web Crypto API, necesitamos procesar el archivo completo
  // pero podemos hacerlo de forma más eficiente
  try {
    const hashBuffer = await crypto.subtle.digest(algorithm, buffer)
    const hashArray = Array.from(new Uint8Array(hashBuffer))
    const result = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
    console.log(`[v0] ${algorithm} por chunks completado`)
    return result
  } catch (error) {
    console.error(`[v0] Error en ${algorithm} por chunks:`, error)
    throw error
  }
}
