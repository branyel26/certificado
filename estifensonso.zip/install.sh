#!/bin/bash

echo "=========================================="
echo "  ESTIFENSO Hash Identifier Installer"
echo "=========================================="
echo ""

# Verificar si se ejecuta como root
if [ "$EUID" -ne 0 ]; then 
    echo "⚠️  Por favor ejecuta este script como root (usa sudo)"
    exit 1
fi

# Variables
APP_DIR="/var/www/hash-identifier"
NGINX_AVAILABLE="/etc/nginx/sites-available/hash-identifier"
NGINX_ENABLED="/etc/nginx/sites-enabled/hash-identifier"

echo "📦 Paso 1: Instalando Nginx..."
apt update
apt install -y nginx

echo ""
echo "📁 Paso 2: Creando directorio de la aplicación..."
mkdir -p $APP_DIR

echo ""
echo "📋 Paso 3: Copiando archivos..."
cp -r index.html css js $APP_DIR/
chown -R www-data:www-data $APP_DIR
chmod -R 755 $APP_DIR

echo ""
echo "⚙️  Paso 4: Configurando Nginx..."
cp nginx.conf $NGINX_AVAILABLE

# Deshabilitar sitio por defecto
if [ -L /etc/nginx/sites-enabled/default ]; then
    rm /etc/nginx/sites-enabled/default
fi

# Habilitar sitio
ln -sf $NGINX_AVAILABLE $NGINX_ENABLED

echo ""
echo "🔍 Paso 5: Verificando configuración de Nginx..."
nginx -t

if [ $? -eq 0 ]; then
    echo ""
    echo "🔄 Paso 6: Reiniciando Nginx..."
    systemctl restart nginx
    systemctl enable nginx
    
    echo ""
    echo "✅ ¡Instalación completada exitosamente!"
    echo ""
    echo "🌐 Tu aplicación está disponible en:"
    echo "   http://$(hostname -I | awk '{print $1}')"
    echo ""
else
    echo ""
    echo "❌ Error en la configuración de Nginx"
    echo "   Revisa los errores arriba"
    exit 1
fi
