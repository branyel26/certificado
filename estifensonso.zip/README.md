# ESTIFENSO - Hash Identify System

Sistema de identificación de hash criptográfico para verificar la autenticidad de archivos ejecutables.

## Características

- ✅ Verificación de hashes MD5, SHA-1 y SHA-256
- ✅ Comparación con base de datos de programas conocidos
- ✅ Interfaz estilo terminal hacker
- ✅ Soporte para archivos de hasta 100MB
- ✅ Cálculo de hash por chunks para archivos grandes
- ✅ 100% estático - No requiere Node.js ni backend

## Instalación en Nginx (Ubuntu)

### 1. Preparar el directorio

\`\`\`bash
# Crear directorio para la aplicación
sudo mkdir -p /var/www/hash-identifier

# Extraer el ZIP en el directorio
sudo unzip hash-identifier.zip -d /var/www/hash-identifier

# Dar permisos correctos
sudo chown -R www-data:www-data /var/www/hash-identifier
sudo chmod -R 755 /var/www/hash-identifier
\`\`\`

### 2. Configurar Nginx

\`\`\`bash
# Copiar archivo de configuración
sudo cp nginx.conf /etc/nginx/sites-available/hash-identifier

# Crear symlink
sudo ln -s /etc/nginx/sites-available/hash-identifier /etc/nginx/sites-enabled/

# Si tienes otro sitio por defecto, deshabilitarlo
sudo rm /etc/nginx/sites-enabled/default

# Verificar configuración
sudo nginx -t

# Recargar Nginx
sudo systemctl reload nginx
\`\`\`

### 3. Verificar instalación

Abre tu navegador en: `http://tu-servidor-ip`

## Estructura del proyecto

\`\`\`
hash-identifier/
├── index.html          # Página principal
├── css/
│   └── styles.css      # Estilos CSS
├── js/
│   └── app.js          # Lógica JavaScript
├── nginx.conf          # Configuración de Nginx
└── README.md           # Este archivo
\`\`\`

## Agregar nuevos programas

Edita el archivo `js/app.js` y agrega nuevos objetos al array `programs`:

\`\`\`javascript
{
    name: "mi-programa.exe",
    description: "Descripción del programa",
    md5: "hash-md5-aqui",
    sha1: "hash-sha1-aqui",
    sha256: "hash-sha256-aqui"
}
\`\`\`

## Dependencias externas (CDN)

- **Lucide Icons**: Para los iconos de interfaz
- **CryptoJS**: Para el cálculo de hashes criptográficos

## Soporte

Para más información visita: [estifenso.me](https://estifenso.me/)

## Licencia

Todos Los Derechos Reservados | Estifenso Hash Identify
