#!/bin/bash

# Script de despliegue con Nginx
# Uso: ./scripts/deploy-nginx.sh

set -e

echo "🚀 Desplegando aplicación con Nginx..."

# Detener contenedores existentes
echo "⏹️  Deteniendo contenedores existentes..."
docker compose down 2>/dev/null || true

# Construir sin caché
echo "🔨 Construyendo imagen Docker..."
docker compose build --no-cache

# Iniciar servicios
echo "▶️  Iniciando servicios..."
docker compose up -d

# Esperar a que los servicios estén listos
echo "⏳ Esperando a que los servicios estén listos..."
sleep 10

# Verificar estado
echo "✅ Verificando estado de los servicios..."
docker compose ps

echo ""
echo "✨ Despliegue completado!"
echo "📊 La aplicación está disponible en:"
echo "   - http://localhost"
echo "   - http://$(hostname -I | awk '{print $1}')"
echo ""
echo "📝 Ver logs:"
echo "   docker compose logs -f"
echo ""
echo "🔍 Ver logs de Nginx:"
echo "   docker compose logs -f nginx"
echo ""
echo "🔍 Ver logs de la aplicación:"
echo "   docker compose logs -f nextjs-app"
echo ""
echo "🛑 Para detener:"
echo "   docker compose down"
