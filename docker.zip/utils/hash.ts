import CryptoJS from "crypto-js"

export async function calculateMD5(arrayBuffer: ArrayBuffer): Promise<string> {
  const wordArray = CryptoJS.lib.WordArray.create(arrayBuffer as any)
  const hash = CryptoJS.MD5(wordArray)
  return hash.toString(CryptoJS.enc.Hex)
}

export async function calculateHash(buffer: ArrayBuffer, algorithm: string): Promise<string> {
  const hashBuffer = await crypto.subtle.digest(algorithm, buffer)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}
