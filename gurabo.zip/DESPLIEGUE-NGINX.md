# Guía de Despliegue en Nginx

Esta guía te ayudará a desplegar tu aplicación Next.js en un servidor Ubuntu con Nginx.

## Requisitos Previos

- Servidor Ubuntu 20.04 o superior
- Acceso SSH al servidor
- Permisos sudo

## Método 1: Despliegue Automático (Recomendado)

### Paso 1: Subir el proyecto al servidor

\`\`\`bash
# En tu máquina local, comprimir el proyecto
zip -r miweb.zip . -x "node_modules/*" ".next/*" ".git/*"

# Subir al servidor (reemplaza usuario@ip con tus datos)
scp miweb.zip usuario@ip-servidor:/home/usuario/

# Conectar al servidor
ssh usuario@ip-servidor

# Descomprimir
unzip miweb.zip -d miweb
cd miweb
\`\`\`

### Paso 2: Ejecutar el script de despliegue

\`\`\`bash
# Dar permisos de ejecución
chmod +x deploy.sh

# Ejecutar el script
./deploy.sh
\`\`\`

El script automáticamente:
- Instala Node.js si no está instalado
- Instala Nginx si no está instalado
- Instala PM2 para gestionar la aplicación
- Copia los archivos al directorio correcto
- Instala dependencias
- Genera el build de producción
- Configura Nginx
- Inicia la aplicación

### Paso 3: Verificar

Tu aplicación debería estar funcionando en:
- `http://tu-ip-servidor`
- `http://tu-dominio.com` (si configuraste un dominio)

## Método 2: Despliegue Manual

### 1. Instalar Node.js

\`\`\`bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
\`\`\`

### 2. Instalar Nginx

\`\`\`bash
sudo apt-get update
sudo apt-get install -y nginx
sudo systemctl enable nginx
sudo systemctl start nginx
\`\`\`

### 3. Instalar PM2

\`\`\`bash
sudo npm install -g pm2
pm2 startup systemd
\`\`\`

### 4. Preparar directorio de la aplicación

\`\`\`bash
sudo mkdir -p /var/www/miweb
sudo chown -R $USER:$USER /var/www/miweb
cd /var/www/miweb
\`\`\`

### 5. Copiar archivos y construir

\`\`\`bash
# Copiar todos los archivos del proyecto aquí
npm install --legacy-peer-deps
npm run build
\`\`\`

### 6. Configurar Nginx

\`\`\`bash
# Copiar configuración
sudo cp nginx-production.conf /etc/nginx/sites-available/miweb

# Crear enlace simbólico
sudo ln -s /etc/nginx/sites-available/miweb /etc/nginx/sites-enabled/miweb

# Eliminar sitio por defecto
sudo rm /etc/nginx/sites-enabled/default

# Probar configuración
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
\`\`\`

### 7. Iniciar aplicación con PM2

\`\`\`bash
cd /var/www/miweb
pm2 start npm --name "miweb" -- start
pm2 save
\`\`\`

## Configurar Dominio (Opcional)

Si tienes un dominio, edita el archivo de configuración de Nginx:

\`\`\`bash
sudo nano /etc/nginx/sites-available/miweb
\`\`\`

Cambia esta línea:
\`\`\`nginx
server_name tu-dominio.com www.tu-dominio.com;
\`\`\`

Luego reinicia Nginx:
\`\`\`bash
sudo systemctl restart nginx
\`\`\`

## Actualizar la Aplicación

Cuando hagas cambios en tu código:

\`\`\`bash
# Método rápido: usa el script de actualización
chmod +x update.sh
./update.sh
\`\`\`

O manualmente:

\`\`\`bash
cd /var/www/miweb
# Copiar archivos nuevos aquí
npm install --legacy-peer-deps
npm run build
pm2 restart miweb
\`\`\`

## Comandos Útiles

### PM2
\`\`\`bash
pm2 status              # Ver estado de aplicaciones
pm2 logs miweb          # Ver logs en tiempo real
pm2 restart miweb       # Reiniciar aplicación
pm2 stop miweb          # Detener aplicación
pm2 start miweb         # Iniciar aplicación
pm2 delete miweb        # Eliminar aplicación
\`\`\`

### Nginx
\`\`\`bash
sudo systemctl status nginx     # Estado de Nginx
sudo systemctl restart nginx    # Reiniciar Nginx
sudo systemctl reload nginx     # Recargar configuración
sudo nginx -t                   # Probar configuración
sudo tail -f /var/log/nginx/miweb-error.log    # Ver logs de error
sudo tail -f /var/log/nginx/miweb-access.log   # Ver logs de acceso
\`\`\`

### Monitoreo
\`\`\`bash
# Ver uso de recursos
htop

# Ver procesos de Node
ps aux | grep node

# Ver puertos en uso
sudo netstat -tulpn | grep LISTEN
\`\`\`

## Solución de Problemas

### La aplicación no inicia
\`\`\`bash
# Ver logs de PM2
pm2 logs miweb

# Verificar que el puerto 3000 no esté en uso
sudo lsof -i :3000

# Reiniciar PM2
pm2 restart miweb
\`\`\`

### Nginx muestra error 502
\`\`\`bash
# Verificar que la aplicación Next.js esté corriendo
pm2 status

# Ver logs de Nginx
sudo tail -f /var/log/nginx/miweb-error.log

# Verificar que Next.js esté en el puerto 3000
curl http://localhost:3000
\`\`\`

### Error al subir archivos grandes
\`\`\`bash
# Editar configuración de Nginx
sudo nano /etc/nginx/sites-available/miweb

# Asegúrate de que esta línea esté presente:
client_max_body_size 100M;

# Reiniciar Nginx
sudo systemctl restart nginx
\`\`\`

### Aplicación lenta o sin respuesta
\`\`\`bash
# Ver uso de memoria y CPU
pm2 monit

# Reiniciar aplicación
pm2 restart miweb

# Si es necesario, aumentar memoria de Node.js
pm2 delete miweb
pm2 start npm --name "miweb" --node-args="--max-old-space-size=2048" -- start
pm2 save
\`\`\`

## Seguridad Adicional

### Configurar Firewall
\`\`\`bash
sudo ufw allow 'Nginx Full'
sudo ufw allow OpenSSH
sudo ufw enable
\`\`\`

### Agregar HTTPS con Let's Encrypt (Recomendado)
\`\`\`bash
# Instalar Certbot
sudo apt-get install certbot python3-certbot-nginx

# Obtener certificado SSL
sudo certbot --nginx -d tu-dominio.com -d www.tu-dominio.com

# El certificado se renovará automáticamente
\`\`\`

## Backup

Para hacer backup de la aplicación:

\`\`\`bash
# Backup de archivos
cd /var/www
sudo tar -czf miweb-backup-$(date +%Y%m%d).tar.gz miweb

# Mover a ubicación segura
sudo mv miweb-backup-*.tar.gz /home/usuario/backups/
\`\`\`

## Contacto y Soporte

Si encuentras problemas durante el despliegue, verifica:
1. Los logs de PM2: `pm2 logs miweb`
2. Los logs de Nginx: `sudo tail -f /var/log/nginx/miweb-error.log`
3. Que todos los puertos estén abiertos en el firewall
4. Que la aplicación se construyó correctamente: `npm run build`
